#include "OpenGLWindow.h"
#include "Mtx.h"
#include "Logger.h"
#include <iostream>

int main(void)
{
	std::cin.ignore();
	OpenGLWindow engine = OpenGLWindow();
	mtx::Matrix4 a = mtx::Matrix4(1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 2.0f, 0.0f, 2.0f, 0.0f, 0.0f, 3.0f, 3.0f, 0.0f, 0.0f, 0.0f, 1.0f);
	Logger::log(a.to_string());
	mtx::Vec4 b = mtx::Vec4(1.0f, 2.0f, 2.0f, 1.0f);
	Logger::log(b.to_string());
	Logger::log("a * b");
	Logger::log((a * b).to_string());
	std::cin.ignore();
}