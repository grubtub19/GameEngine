#pragma once

static class Logger {
	public:
		static void log(const std::string&);
};