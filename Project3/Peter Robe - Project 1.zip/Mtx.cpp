#include "Mtx.h"
#include <cmath>
#include "Logger.h"

# define M_PI           3.14159265358979323846

float mtx::to_radians(float const &radians) {
	return radians / 360 * (float)M_PI * 2;
}

mtx::Vec3::Vec3() {}

mtx::Vec3::Vec3(float x, float y, float z) : x(x), y(y), z(z) {}

mtx::Vec3::Vec3(const Vec3 &vector) : x(vector.x), y(vector.y), z(vector.z) {}

mtx::Vec3::Vec3(const Vec4 &vector) : x(vector.get_x()), y(vector.get_y()), z(vector.get_z()) {}

std::string mtx::Vec3::to_string() {
	std::string rtn;
	rtn.reserve(50);
	std::string str = std::to_string(x);
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	str = std::to_string(y);
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	str = std::to_string(z);
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	return rtn;
}

/*----------------------
		 ADDITION
  ----------------------*/

/**
 *	Vec4 const + Vec4
 *	NOTE: Follows Vector + Point rules for w
 */
mtx::Vec3 mtx::Vec3::operator+(Vec3 const &right) const {
	return Vec3(x + right.x, y + right.y, z + right.z);
}

/**
 *	Vec3 const + Vec3
 *	NOTE: Follows Vector + Point rules for w
 */
mtx::Vec3 mtx::Vec3::operator+(Vec4 const &right) const {
	return Vec3(x + right.get_x(), y + right.get_y(), z + right.get_z());
}

/**
 * Vec4 const + float
 */
mtx::Vec3 mtx::Vec3::operator+(float const &right) const {
	return Vec3(x + right, y + right, z + right);
}

/**
 *	Vec4 += Vec4
 *	NOTE: w stays the same
 */
mtx::Vec3& mtx::Vec3::operator+=(Vec3 const &right) {
	x += right.x;
	y += right.y;
	z += right.z;
	return *this;
}

/**
 *	Vec4 += Vec3
 *	NOTE: w stays the same
 */
mtx::Vec3& mtx::Vec3::operator+=(Vec4 const &right) {
	x += right.get_x();
	y += right.get_y();
	z += right.get_x();
	return *this;
}

/**
 *	Vec4 += float
 */
mtx::Vec3& mtx::Vec3::operator+=(float const &right) {
	x += right;
	y += right;
	z += right;
	return *this;
}

/*----------------------
		SUBTRACTION
  ----------------------*/

/**
 *	Vec4 const - Vec4
 *	NOTE: Follows Vector - Point rules for w
 */
mtx::Vec3 mtx::Vec3::operator-(Vec3 const &right) const {
	return Vec3(x - right.x, y - right.y, z - right.z);
}

/**
 *	Vec4 const - Vec3
 *	NOTE: Follows Vector - Point rules for w
 */
mtx::Vec3 mtx::Vec3::operator-(Vec4 const &right) const {
	return Vec3(x - right.get_x(), y - right.get_y(), z - right.get_z());
}

/**
 *	Vect4 - float
 */
mtx::Vec3 mtx::Vec3::operator-(float const &right) const {
	return Vec3(x - right, y - right, z - right);
}

/**
 *	Vec4 -= Vec4
 *	NOTE: w stays the same
 */
mtx::Vec3& mtx::Vec3::operator-=(Vec3 const &right) {
	x -= right.x;
	y -= right.y;
	z -= right.z;
	return *this;
}

/**
 *	Vec4 -= Vec4
 *	NOTE: w stays the same
 */
mtx::Vec3& mtx::Vec3::operator-=(Vec4 const &right) {
	x -= right.get_x();
	y -= right.get_y();
	z -= right.get_z();
	return *this;
}

/**
 *	Vec4 -= float
 */
mtx::Vec3& mtx::Vec3::operator-=(float const &right) {
	x -= right;
	y -= right;
	z -= right;
	return *this;
}


/*----------------------
	  MULTIPLICATION
  ----------------------*/

  // Vec4 * scalar

/**
 *
 */
mtx::Vec3 mtx::Vec3::operator*(float const &right) const {
	return Vec3(x * right, y * right, z * right);
}

/**
 *	Vec4 *= float
 */
mtx::Vec3& mtx::Vec3::operator*=(float const &right) {
	x *= right;
	y *= right;
	z *= right;
	return *this;
}

/*----------------------
		 DIVISION
  ----------------------*/

/**
 *	Vec4 / float
 */
mtx::Vec3 mtx::Vec3::operator/(float const &right) const {
	return Vec3(x / right, y / right, z / right);
}

/**
 *	Vec4 /= float
 */
mtx::Vec3& mtx::Vec3::operator/=(float const &right) {
	x /= right;
	y /= right;
	z /= right;
	return *this;
}

/*----------------------
		 EQUALITY
  ----------------------*/

  /**
   *	Vec4 == Vec3
   *	NOTE: Vector != Point
   */
bool mtx::Vec3::operator==(Vec4 const &right) const {
	return x == right.get_x() && y == right.get_y() && z == right.get_z();
}

/**
 *	Vec4 == Vec4
 *	NOTE: Vector != Point
 */
bool mtx::Vec3::operator==(Vec3 const &right) const {
	return x == right.x && y == right.y && z == right.z;
}

/**
 *	Vec4 != Vec3
 *	NOTE: Vector != Point
 */
bool mtx::Vec3::operator!=(Vec4 const &right) const {
	return x != right.get_x() || y != right.get_y() || z != right.get_z(); //FIX
}

/**
 *	Vec4 != Vec4
 *	NOTE: Vector != Point
 */
bool mtx::Vec3::operator!=(Vec3 const &right) const {
	return x != right.x || y != right.y || z != right.z;
}

/**
 *	|Vec4| in 3D
 */
float mtx::Vec3::magnitude() {
	return std::sqrt(x * x + y * y + z * z);
}

/**
 *	|Vec4|^2 in 3D
 */
float mtx::Vec3::magnitude_squared() {
	return x * x + y * y + z * z;
}

/**
 *	Normalizes the Vec4
 */
mtx::Vec3& mtx::Vec3::normalize() {
	float mag = magnitude();
	if (mag > 0) {
		*this /= mag;
	}
	return (*this);
}

/**
 *	Returns a normalized version of a the Vec4
 */
mtx::Vec3 mtx::Vec3::normal() {
	float mag = magnitude();
	if (mag > 0) {
		return Vec3(x / mag, y / mag, z / mag);
	}
	else {
		return Vec3(*this);
	}
}

/**
 *	Returns the dot product of two Vec3
 */
float mtx::Vec3::dot(Vec3 const &right) const {
	return x * right.x + y * right.y + z * right.z;
}

/**
 *	Returns the dot product of a Vec3 and a Vec4
 */
float mtx::Vec3::dot(Vec4 const &right) const {
	return x * right.get_x() + y * right.get_y() + z * right.get_z();
}

/**
 *	Returns the cross product of a Vec4 and a Vec3
 *	Always returns a Vector, not a Point (w = 0)
 */
mtx::Vec3 mtx::Vec3::cross(Vec4 const &right) const {
	return Vec3(
		y * right.get_z() - z * right.get_y(),
		-(x * right.get_z() - z * right.get_x()),
		x * right.get_y() - y * right.get_x());
}

/**
 *	Returns the cross product of two Vec4
 *	Always returns a Vector, not a Point (w = 0)
 */
mtx::Vec3 mtx::Vec3::cross(Vec3 const &right) const {
	return Vec3(
		y * right.z - z * right.y,
		-(x * right.z - z * right.x),
		x * right.y - y * right.x);
}

/**
 *	Linear Interpolation starting at the current Vec4 (time = 0) and moving toward the "right" Vec3 (time = 1)
 */
mtx::Vec3 mtx::Vec3::lerp(Vec4 const &right, float const time) {
	return  (*this) * (1 - time) + right * time;
}

/**
 *	Linear Interpolation starting at the current Vec4 (time = 0) and moving toward the "right" Vec4 (time = 1)
 */
mtx::Vec3 mtx::Vec3::lerp(Vec3 const &right, float const time) {
	return  (*this) * (1 - time) + right * time;
}

/**
 *	Projection of this Vec4 onto a Vec3
 *	Returns a Vector, not a Point (w = 0)
 */
mtx::Vec3 mtx::Vec3::project_onto(Vec4 const &right) {
	return Vec3(right * (dot(right) / magnitude_squared()));
}

/**
 *	Projection of this Vec4 onto another Vec4
 *	Returns a Vector, not a Point (w = 0)
 */
mtx::Vec3 mtx::Vec3::project_onto(Vec3 const &right) {
	return right * (dot(right) / magnitude_squared());
}

/**
 * Rotates Vec3 by a Quaternion
 * NOTE: Normalizes the quaternion's original value during
 */
mtx::Vec3& mtx::Vec3::rotate(Quaternion &quat) {
	quat.normalize();
	*this = (quat * Quaternion(*this) * quat.conjugate()).vector;
	return (*this);
}

/**
 *	Returns pointer to the start of the Vec4. Useful for OpenGL calls
 */
float* mtx::Vec3::data_ptr() {
	return &x;
}


mtx::Vec4::Vec4() {}

mtx::Vec4::Vec4(float x, float y, float z, float w) : vector{ x, y, z }, w(w) {}

mtx::Vec4::Vec4(const Vec3 &vec, float const &w) : vector(vec), w(w) {}

mtx::Vec4::Vec4(const Vec4 &vec) : vector(vec), w(vec.w) {}

float& mtx::Vec4::get_x() {
	return vector.x;
}

float& mtx::Vec4::get_y() {
	return vector.y;
}

float& mtx::Vec4::get_z() {
	return vector.z;
}

float mtx::Vec4::get_x() const {
	return vector.x;
}

float mtx::Vec4::get_y() const {
	return vector.y;
}

float mtx::Vec4::get_z() const {
	return vector.z;
}

std::string mtx::Vec4::to_string() {
	std::string rtn;
	rtn.reserve(50);
	std::string str = std::to_string(get_x());
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	str = std::to_string(get_y());
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	str = std::to_string(get_z());
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	str = std::to_string(w);
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	return rtn;
}

/*----------------------
		 ADDITION
  ----------------------*/

/**
 *	Vec3 const + Vec3
 *	NOTE: Follows Vector + Point rules for w
 */
mtx::Vec4 mtx::Vec4::operator+(Vec3 const &right) const {
	return Vec4(get_x() + right.x, get_y() + right.y, get_z() + right.z, w);
}

/**
 *	Vec4 const + Vec4
 *	NOTE: Follows Vector + Point rules for w
 */
mtx::Vec4 mtx::Vec4::operator+(Vec4 const &right) const {
	return Vec4(get_x() + right.get_x(), get_y() + right.get_y(), get_z() + right.get_z(), std::fmax(w, right.w));
}

/**
 * Vec4 const + float
 */
mtx::Vec4 mtx::Vec4::operator+(float const &right) const {
	return Vec4(get_x() + right, get_y() + right, get_z() + right, w);
}

/**
 *	Vec4 += Vec3
 *	NOTE: w stays the same
 */
mtx::Vec4& mtx::Vec4::operator+=(Vec3 const &right) {
	get_x() += right.x;
	get_y() += right.y;
	get_z() += right.z;
	return *this;
}

/**
 *	Vec4 += Vec4
 *	NOTE: w stays the same
 */
mtx::Vec4& mtx::Vec4::operator+=(Vec4 const &right) {
	get_x() += right.get_x();
	get_y() += right.get_y();
	get_z() += right.get_z();
	return *this;
}

/**
 *	Vec4 += float
 */
mtx::Vec4& mtx::Vec4::operator+=(float const &right) {
	get_x() += right;
	get_y() += right;
	get_z() += right;
	return *this;
}

/*----------------------
		SUBTRACTION
  ----------------------*/

/**
 *	Vec4 const - Vec3
 *	NOTE: Follows Vector - Point rules for w
 */
mtx::Vec4 mtx::Vec4::operator-(Vec3 const &right) const {
	return Vec4(get_x() - right.x, get_y() - right.y, get_z() - right.z, w);
}

/**
 *	Vec4 const - Vec4
 *	NOTE: Follows Vector - Point rules for w
 */
mtx::Vec4 mtx::Vec4::operator-(Vec4 const &right) const {
	return Vec4(get_x() - right.get_x(), get_y() - right.get_y(), get_z() - right.get_z(), std::fmax(w, right.w));
}

/**
 *	Vect4 - float
 */
mtx::Vec4 mtx::Vec4::operator-(float const &right) const {
	return Vec4(get_x() - right, get_y() - right, get_z() - right, w);
}

/**
 *	Vec4 -= Vec4
 *	NOTE: w stays the same
 */
mtx::Vec4& mtx::Vec4::operator-=(Vec3 const &right) {
	get_x() -= right.x;
	get_y() -= right.y;
	get_z() -= right.z;
	return *this;
}

/**
 *	Vec4 -= Vec4
 *	NOTE: w stays the same
 */
mtx::Vec4& mtx::Vec4::operator-=(Vec4 const &right) {
	get_x() -= right.get_x();
	get_y() -= right.get_y();
	get_z() -= right.get_z();
	return *this;
}

/**
 *	Vec4 -= float
 */
mtx::Vec4& mtx::Vec4::operator-=(float const &right) {
	get_x() -= right;
	get_y() -= right;
	get_z() -= right;
	return *this;
}


/*----------------------
	  MULTIPLICATION
  ----------------------*/

  // Vec4 * scalar

/**
 *
 */
mtx::Vec4 mtx::Vec4::operator*(float const &right) const {
	return Vec4(get_x() * right, get_y() * right, get_z() * right, w);
}

/**
 *	Vec4 *= float
 */
mtx::Vec4& mtx::Vec4::operator*=(float const &right) {
	get_x() *= right;
	get_y() *= right;
	get_z() *= right;
	return *this;
}

/*----------------------
		 DIVISION
  ----------------------*/

/**
 *	Vec4 / float
 */
mtx::Vec4 mtx::Vec4::operator/(float const &right) const {
	return Vec4(get_x() / right, get_y() / right, get_z() / right, w);
}

/**
 *	Vec4 /= float
 */
mtx::Vec4& mtx::Vec4::operator/=(float const &right) {
	get_x() /= right;
	get_y() /= right;
	get_z() /= right;
	return *this;
}

/*----------------------
		 EQUALITY
  ----------------------*/

  /**
   *	Vec4 == Vec3
   *	NOTE: Vector != Point
   */
bool mtx::Vec4::operator==(Vec3 const &right) const {
	return get_x() == right.x && get_y() == right.y && get_z() == right.z;
}

/**
 *	Vec4 == Vec4
 *	NOTE: Vector != Point
 */
bool mtx::Vec4::operator==(Vec4 const &right) const {
	return get_x() == right.get_x() && get_y() == right.get_y() && get_z() == right.get_z();
}

/**
 *	Vec4 != Vec3
 *	NOTE: Vector != Point
 */
bool mtx::Vec4::operator!=(Vec3 const &right) const {
	return get_x() != right.x || get_y() != right.y || get_z() != right.z;
}

/**
 *	Vec4 != Vec4
 *	NOTE: Vector != Point
 */
bool mtx::Vec4::operator!=(Vec4 const &right) const {
	return get_x() != right.get_x() || get_y() != right.get_y() || get_z() != right.get_z();
}

/**
 *	|Vec4| in 3D
 */
float mtx::Vec4::magnitude() {
	return std::sqrt(get_x() * get_x() + get_y() * get_y() + get_z() * get_z());
}

/**
 *	|Vec4|^2 in 3D
 */
float mtx::Vec4::magnitude_squared() {
	return get_x() * get_x() + get_y() * get_y() + get_z() * get_z();
}

/**
 *	Normalizes the Vec4
 */
mtx::Vec4& mtx::Vec4::normalize() {
	float mag = magnitude();
	if (mag > 0) {
		*this /= mag;
	}
	return (*this);
}

/**
 *	Returns a normalized version of a the Vec4
 */
mtx::Vec4 mtx::Vec4::normal() {
	float mag = magnitude();
	if (mag > 0) {
		return Vec4(get_x() / mag, get_y() / mag, get_z() / mag, w);
	}
	else {
		return Vec4(*this);
	}
}

/**
 *	Returns the dot product of two Vec4
 */
float mtx::Vec4::dot(Vec3 const &right) {
	return get_x() * right.x + get_y() * right.y + get_z() * right.z;
}

/**
 *	Returns the dot product of two Vec4
 */
float mtx::Vec4::dot(Vec4 const &right) {
	return get_x() * right.get_x() + get_y() * right.get_y() + get_z() * right.get_z();
}

/**
 *	Returns the cross product of a Vec4 and a Vec3
 *	Always returns a Vector, not a Point (w = 0)
 */
mtx::Vec4 mtx::Vec4::cross(Vec3 const &right) const {
	return Vec4(
		get_y() * right.z - get_z() * right.y,
		-(get_x() * right.z - get_z() * right.x),
		get_x() * right.y - get_y() * right.x,
		0);
}

/**
 *	Returns the cross product of two Vec4
 *	Always returns a Vector, not a Point (w = 0)
 */
mtx::Vec4 mtx::Vec4::cross(Vec4 const &right) const {
	return Vec4(
		get_y() * right.get_z() - get_z() * right.get_y(),
		-(get_x() * right.get_z() - get_z() * right.get_x()),
		get_x() * right.get_y() - get_y() * right.get_x(),
		0);
}

/**
 *	Linear Interpolation starting at the current Vec4 (time = 0) and moving toward the "right" Vec3 (time = 1)
 */
mtx::Vec4 mtx::Vec4::lerp(Vec3 const &right, float const time) {
	return  (*this) * (1 - time) + right * time;
}

/**
 *	Linear Interpolation starting at the current Vec4 (time = 0) and moving toward the "right" Vec4 (time = 1)
 */
mtx::Vec4 mtx::Vec4::lerp(Vec4 const &right, float const time) {
	return  (*this) * (1 - time) + right * time;
}

/**
 *	Projection of this Vec4 onto a Vec3
 *	Returns a Vector, not a Point (w = 0)
 */
mtx::Vec4 mtx::Vec4::project_onto(Vec3 const &right) {
	return Vec4(right * (dot(right) / magnitude_squared()), 1.0f);
}

/**
 *	Projection of this Vec4 onto another Vec4
 *	Returns a Vector, not a Point (w = 0)
 */
mtx::Vec4 mtx::Vec4::project_onto(Vec4 const &right) {
	return right * (dot(right) / magnitude_squared());
}

/**
 *	Returns pointer to the start of the Vec4. Useful for OpenGL calls
 */
float* mtx::Vec4::data_ptr() {
	return &get_x();
}

//-------------------------------
//         MATRIX TIME
//-------------------------------

/**
 * Default Constructor
 */
mtx::Matrix4::Matrix4() {}

mtx::Matrix4::Matrix4(bool const &identity) : array{ 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f } {

}

/**
 * Constructor that fills every entry with the parameter
 */
mtx::Matrix4::Matrix4(float const &num) : array{ num, num, num, num, num, num, num, num, num, num, num, num, num, num, num, num } {}

/**
 * Constructor of 16 floats
 */
mtx::Matrix4::Matrix4(float a1, float a2, float a3, float a4, float b1, float b2, float b3, float b4, float c1, float c2, float c3, float c4, float d1, float d2, float d3, float d4) :
	array{ a1, a2, a3, a4, b1, b2, b3, b4, c1, c2, c3, c4, d1, d2, d3, d4 } {}

mtx::Matrix4::Matrix4(Matrix4 const &original) {
	for (int i = 0; i < 16; i++) {
		array[i] = original[i];
	}
}

/**
 * Formats the Matrix4 into a 4x4 string
 */
std::string mtx::Matrix4::to_string() {
	std::string rtn;
	rtn.reserve(200);
	for (int i = 0; i < 16; i++) {
		//Logger::log(std::to_string(rtn.capacity()));
		std::string str = std::to_string(array[i]);
		str.erase(str.find_last_not_of('0') + 1, std::string::npos);
		str.erase(str.find_last_not_of('.') + 1, std::string::npos);
		rtn += str + " ";
		if ((i + 1) % 4 == 0) {
			rtn += "\n";
		}
	}
	return rtn;
}

/**
 * Sets the matrix to the identity matrix
 */
mtx::Matrix4& mtx::Matrix4::make_identity() {
	array[0] = 1.0f;
	array[1] = 0.0f;
	array[2] = 0.0f;
	array[3] = 0.0f;

	array[4] = 0.0f;
	array[5] = 1.0f;
	array[6] = 0.0f;
	array[7] = 0.0f;

	array[8] = 0.0f;
	array[9] = 0.0f;
	array[10] = 1.0f;
	array[11] = 0.0f;

	array[12] = 0.0f;
	array[13] = 0.0f;
	array[14] = 0.0f;
	array[15] = 1.0f;
	return (*this);
}

/**
 * Sets the matrix to the translation matrix given the translation floats x, y, and z
 */
mtx::Matrix4& mtx::Matrix4::make_translation(float const &x, float const &y, float const &z) {
	array[0] = 1.0f;	array[1] = 0.0f;	array[2] = 0.0f;	array[3] = x;
	array[4] = 0.0f;	array[5] = 1.0f;	array[6] = 0.0f;	array[7] = y;
	array[8] = 0.0f;	array[9] = 0.0f;	array[10] = 1.0f;	array[11] = z;
	array[12] = 0.0f;	array[13] = 0.0f;	array[14] = 0.0f;	array[15] = 1.0f;
	return (*this);
}

/**
 * Sets the matrix to the translation matrix given the translation Vec4
 */
mtx::Matrix4& mtx::Matrix4::make_translation(Vec4 const &direction) {
	array[0] = 1.0f;	array[1] = 0.0f;	array[2] = 0.0f;	array[3] = direction.get_x();
	array[4] = 0.0f;	array[5] = 1.0f;	array[6] = 0.0f;	array[7] = direction.get_y();
	array[8] = 0.0f;	array[9] = 0.0f;	array[10] = 1.0f;	array[11] = direction.get_z();
	array[12] = 0.0f;	array[13] = 0.0f;	array[14] = 0.0f;	array[15] = 1.0f;
	return (*this);
}

/**
 * Translates the Matrix4 by x, y, and z
 * @returns Matrix4& (*this)
 */
mtx::Matrix4& mtx::Matrix4::translate(float const &x, float const &y, float const &z) {
	array[3] += x;
	array[7] += y;
	array[11] += z;
	return (*this);
}

/**
 * Translates the Matrix4 by the Vec4
 * @returns (*this)
 */
mtx::Matrix4& mtx::Matrix4::translate(Vec4 const &direction) {
	array[3] += direction.get_x();
	array[7] += direction.get_y();
	array[11] += direction.get_z();
	return (*this);
}

/**
 * Assigns the Matrix4 to a scale matrix
 */
mtx::Matrix4& mtx::Matrix4::make_scale(float const &x, float const &y, float const &z) {
	array[0] = x;		array[1] = 0.0f;	array[2] = 0.0f;	array[3] = 0.0f;
	array[4] = 0.0f;	array[5] = y;		array[6] = 0.0f;	array[7] = 0.0f;
	array[8] = 0.0f;	array[9] = 0.0f;	array[10] = z;		array[11] = 0.0f;
	array[12] = 0.0f;	array[13] = 0.0f;	array[14] = 0.0f;	array[15] = 1.0f;
	return (*this);
}

/**
 * Left hand multiplication of a scale matrix to the Matrix4
 */
mtx::Matrix4& mtx::Matrix4::scale(float const &x, float const &y, float const &z) {
	array[0] *= x;
	array[1] *= x;
	array[2] *= x;
	array[4] *= y;
	array[5] *= y;
	array[6] *= y;
	array[8] *= z;
	array[9] *= z;
	array[10] *= z;
	return (*this);
}

/**
 * Inverse of a Matrix
 * @returns Matrix4 result
 */
mtx::Matrix4 mtx::Matrix4::inverse() {
	//
	// Inversion by Cramer's rule.  Code taken from an Intel publication
	//
	mtx::Matrix4 result;
	float tmp[12]; /* temp array for pairs */
	float src[16]; /* array of transpose source matrix */
	float det; /* determinant */
	/* transpose matrix */
	for (int i = 0; i < 4; i++)
	{
		src[i + 0] = array[4 * i];
		src[i + 4] = array[4 * i + 1];
		src[i + 8] = array[4 * i + 2];
		src[i + 12] = array[4 * i + 3];
	}
	/* calculate pairs for first 8 elements (cofactors) */
	tmp[0] = src[10] * src[15];
	tmp[1] = src[11] * src[14];
	tmp[2] = src[9] * src[15];
	tmp[3] = src[11] * src[13];
	tmp[4] = src[9] * src[14];
	tmp[5] = src[10] * src[13];
	tmp[6] = src[8] * src[15];
	tmp[7] = src[11] * src[12];
	tmp[8] = src[8] * src[14];
	tmp[9] = src[10] * src[12];
	tmp[10] = src[8] * src[13];
	tmp[11] = src[9] * src[12];
	/* calculate first 8 elements (cofactors) */
	result[0] = tmp[0] * src[5] + tmp[3] * src[6] + tmp[4] * src[7];
	result[0] -= tmp[1] * src[5] + tmp[2] * src[6] + tmp[5] * src[7];
	result[1] = tmp[1] * src[4] + tmp[6] * src[6] + tmp[9] * src[7];
	result[1] -= tmp[0] * src[4] + tmp[7] * src[6] + tmp[8] * src[7];
	result[2] = tmp[2] * src[4] + tmp[7] * src[5] + tmp[10] * src[7];
	result[2] -= tmp[3] * src[4] + tmp[6] * src[5] + tmp[11] * src[7];
	result[3] = tmp[5] * src[4] + tmp[8] * src[5] + tmp[11] * src[6];
	result[3] -= tmp[4] * src[4] + tmp[9] * src[5] + tmp[10] * src[6];
	result[4] = tmp[1] * src[1] + tmp[2] * src[2] + tmp[5] * src[3];
	result[4] -= tmp[0] * src[1] + tmp[3] * src[2] + tmp[4] * src[3];
	result[5] = tmp[0] * src[0] + tmp[7] * src[2] + tmp[8] * src[3];
	result[5] -= tmp[1] * src[0] + tmp[6] * src[2] + tmp[9] * src[3];
	result[6] = tmp[3] * src[0] + tmp[6] * src[1] + tmp[11] * src[3];
	result[6] -= tmp[2] * src[0] + tmp[7] * src[1] + tmp[10] * src[3];
	result[7] = tmp[4] * src[0] + tmp[9] * src[1] + tmp[10] * src[2];
	result[7] -= tmp[5] * src[0] + tmp[8] * src[1] + tmp[11] * src[2];
	/* calculate pairs for second 8 elements (cofactors) */
	tmp[0] = src[2] * src[7];
	tmp[1] = src[3] * src[6];
	tmp[2] = src[1] * src[7];
	tmp[3] = src[3] * src[5];
	tmp[4] = src[1] * src[6];
	tmp[5] = src[2] * src[5];

	tmp[6] = src[0] * src[7];
	tmp[7] = src[3] * src[4];
	tmp[8] = src[0] * src[6];
	tmp[9] = src[2] * src[4];
	tmp[10] = src[0] * src[5];
	tmp[11] = src[1] * src[4];
	/* calculate second 8 elements (cofactors) */
	result[8] = tmp[0] * src[13] + tmp[3] * src[14] + tmp[4] * src[15];
	result[8] -= tmp[1] * src[13] + tmp[2] * src[14] + tmp[5] * src[15];
	result[9] = tmp[1] * src[12] + tmp[6] * src[14] + tmp[9] * src[15];
	result[9] -= tmp[0] * src[12] + tmp[7] * src[14] + tmp[8] * src[15];
	result[10] = tmp[2] * src[12] + tmp[7] * src[13] + tmp[10] * src[15];
	result[10] -= tmp[3] * src[12] + tmp[6] * src[13] + tmp[11] * src[15];
	result[11] = tmp[5] * src[12] + tmp[8] * src[13] + tmp[11] * src[14];
	result[11] -= tmp[4] * src[12] + tmp[9] * src[13] + tmp[10] * src[14];
	result[12] = tmp[2] * src[10] + tmp[5] * src[11] + tmp[1] * src[9];
	result[12] -= tmp[4] * src[11] + tmp[0] * src[9] + tmp[3] * src[10];
	result[13] = tmp[8] * src[11] + tmp[0] * src[8] + tmp[7] * src[10];
	result[13] -= tmp[6] * src[10] + tmp[9] * src[11] + tmp[1] * src[8];
	result[14] = tmp[6] * src[9] + tmp[11] * src[11] + tmp[3] * src[8];
	result[14] -= tmp[10] * src[11] + tmp[2] * src[8] + tmp[7] * src[9];
	result[15] = tmp[10] * src[10] + tmp[4] * src[8] + tmp[9] * src[9];
	result[15] -= tmp[8] * src[9] + tmp[11] * src[10] + tmp[5] * src[8];
	/* calculate determinant */
	det = src[0] * result[0] + src[1] * result[1] + src[2] * result[2] + src[3] * result[3];
	/* calculate matrix inverse */
	det = 1.0f / det;

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			result[4 * i + j] *= det;
		}
	}
	return result;
}

/**
 * Inverse of a Matrix
 * @returns Matrix4& (*this)
 */
mtx::Matrix4& mtx::Matrix4::invert() {
	//
// Inversion by Cramer's rule.  Code taken from an Intel publication
//
	float tmp[12]; /* temp array for pairs */
	float src[16]; /* array of transpose source matrix */
	float det; /* determinant */
	/* transpose matrix */
	for (int i = 0; i < 4; i++)
	{
		src[i + 0] = array[4 * i];
		src[i + 4] = array[4 * i + 1];
		src[i + 8] = array[4 * i + 2];
		src[i + 12] = array[4 * i + 3];
	}
	/* calculate pairs for first 8 elements (cofactors) */
	tmp[0] = src[10] * src[15];
	tmp[1] = src[11] * src[14];
	tmp[2] = src[9] * src[15];
	tmp[3] = src[11] * src[13];
	tmp[4] = src[9] * src[14];
	tmp[5] = src[10] * src[13];
	tmp[6] = src[8] * src[15];
	tmp[7] = src[11] * src[12];
	tmp[8] = src[8] * src[14];
	tmp[9] = src[10] * src[12];
	tmp[10] = src[8] * src[13];
	tmp[11] = src[9] * src[12];
	/* calculate first 8 elements (cofactors) */
	array[0] = tmp[0] * src[5] + tmp[3] * src[6] + tmp[4] * src[7];
	array[0] -= tmp[1] * src[5] + tmp[2] * src[6] + tmp[5] * src[7];
	array[1] = tmp[1] * src[4] + tmp[6] * src[6] + tmp[9] * src[7];
	array[1] -= tmp[0] * src[4] + tmp[7] * src[6] + tmp[8] * src[7];
	array[2] = tmp[2] * src[4] + tmp[7] * src[5] + tmp[10] * src[7];
	array[2] -= tmp[3] * src[4] + tmp[6] * src[5] + tmp[11] * src[7];
	array[3] = tmp[5] * src[4] + tmp[8] * src[5] + tmp[11] * src[6];
	array[3] -= tmp[4] * src[4] + tmp[9] * src[5] + tmp[10] * src[6];
	array[4] = tmp[1] * src[1] + tmp[2] * src[2] + tmp[5] * src[3];
	array[4] -= tmp[0] * src[1] + tmp[3] * src[2] + tmp[4] * src[3];
	array[5] = tmp[0] * src[0] + tmp[7] * src[2] + tmp[8] * src[3];
	array[5] -= tmp[1] * src[0] + tmp[6] * src[2] + tmp[9] * src[3];
	array[6] = tmp[3] * src[0] + tmp[6] * src[1] + tmp[11] * src[3];
	array[6] -= tmp[2] * src[0] + tmp[7] * src[1] + tmp[10] * src[3];
	array[7] = tmp[4] * src[0] + tmp[9] * src[1] + tmp[10] * src[2];
	array[7] -= tmp[5] * src[0] + tmp[8] * src[1] + tmp[11] * src[2];
	/* calculate pairs for second 8 elements (cofactors) */
	tmp[0] = src[2] * src[7];
	tmp[1] = src[3] * src[6];
	tmp[2] = src[1] * src[7];
	tmp[3] = src[3] * src[5];
	tmp[4] = src[1] * src[6];
	tmp[5] = src[2] * src[5];

	tmp[6] = src[0] * src[7];
	tmp[7] = src[3] * src[4];
	tmp[8] = src[0] * src[6];
	tmp[9] = src[2] * src[4];
	tmp[10] = src[0] * src[5];
	tmp[11] = src[1] * src[4];
	/* calculate second 8 elements (cofactors) */
	array[8] = tmp[0] * src[13] + tmp[3] * src[14] + tmp[4] * src[15];
	array[8] -= tmp[1] * src[13] + tmp[2] * src[14] + tmp[5] * src[15];
	array[9] = tmp[1] * src[12] + tmp[6] * src[14] + tmp[9] * src[15];
	array[9] -= tmp[0] * src[12] + tmp[7] * src[14] + tmp[8] * src[15];
	array[10] = tmp[2] * src[12] + tmp[7] * src[13] + tmp[10] * src[15];
	array[10] -= tmp[3] * src[12] + tmp[6] * src[13] + tmp[11] * src[15];
	array[11] = tmp[5] * src[12] + tmp[8] * src[13] + tmp[11] * src[14];
	array[11] -= tmp[4] * src[12] + tmp[9] * src[13] + tmp[10] * src[14];
	array[12] = tmp[2] * src[10] + tmp[5] * src[11] + tmp[1] * src[9];
	array[12] -= tmp[4] * src[11] + tmp[0] * src[9] + tmp[3] * src[10];
	array[13] = tmp[8] * src[11] + tmp[0] * src[8] + tmp[7] * src[10];
	array[13] -= tmp[6] * src[10] + tmp[9] * src[11] + tmp[1] * src[8];
	array[14] = tmp[6] * src[9] + tmp[11] * src[11] + tmp[3] * src[8];
	array[14] -= tmp[10] * src[11] + tmp[2] * src[8] + tmp[7] * src[9];
	array[15] = tmp[10] * src[10] + tmp[4] * src[8] + tmp[9] * src[9];
	array[15] -= tmp[8] * src[9] + tmp[11] * src[10] + tmp[5] * src[8];
	/* calculate determinant */
	det = src[0] * array[0] + src[1] * array[1] + src[2] * array[2] + src[3] * array[3];
	/* calculate matrix inverse */
	det = 1.0f / det;

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			array[4 * i + j] *= det;
		}
	}
	return (*this);
}

/**
 * Transposes the Matrix4
 */
mtx::Matrix4& mtx::Matrix4::transpose() {
	float temp;
	temp = array[1];
	array[1] = array[4];
	array[4] = temp;

	temp = array[2];
	array[2] = array[8];
	array[8] = temp;

	temp = array[3];
	array[3] = array[12];
	array[12] = temp;

	temp = array[6];
	array[6] = array[9];
	array[9] = temp;

	temp = array[7];
	array[7] = array[13];
	array[13] = temp;

	temp = array[11];
	array[11] = array[14];
	array[14] = temp;
	return (*this);
}

mtx::Matrix4& mtx::Matrix4::rotate(Quaternion const &quat) {
	Matrix4 rtn = Matrix4(true);
	rtn[0] = 1 - 2 * quat.get_y() * quat.get_y() - quat.get_z() * quat.get_z();
	rtn[1] = 2 * quat.get_x() * quat.get_y() + 2 * quat.get_z() * quat.w;
	rtn[2] = 2 * quat.get_x() * quat.get_z() - 2 * quat.get_y() * quat.w;
	rtn[4] = 2 * quat.get_x() * quat.get_y() - 2 * quat.get_z() * quat.w;
	rtn[5] = 1 - 2 * quat.get_x() * quat.get_x() - 2 * quat.get_z() * quat.get_z();
	rtn[6] = 2 * quat.get_y() * quat.get_z() + 2 * quat.get_x() * quat.w;
	rtn[8] = 2 * quat.get_x() * quat.get_z() + 2 * quat.get_y() * quat.w;
	rtn[9] = 2 * quat.get_y() * quat.get_z() - 2 * quat.get_x() * quat.w;
	rtn[10] = 1 - 2 * quat.get_x() * quat.get_x() - 2 * quat.get_y() * quat.get_y();
	concatenate(rtn);
	return (*this);
}

mtx::Matrix4& mtx::Matrix4::make_rotation(Quaternion const &quat) {
	array[0] = 1 - 2 * quat.get_y() * quat.get_y() - 2 * quat.get_z() * quat.get_z();
	array[1] = 2 * quat.get_x() * quat.get_y() - 2 * quat.get_z() * quat.w;
	array[2] = 2 * quat.get_x() * quat.get_z() + 2 * quat.get_y() * quat.w;
	array[3] = 0;
	array[4] = 2 * quat.get_x() * quat.get_y() + 2 * quat.get_z() * quat.w;
	array[5] = 1 - 2 * quat.get_x() * quat.get_x() - 2 * quat.get_z() * quat.get_z();
	array[6] = 2 * quat.get_y() * quat.get_z() - 2 * quat.get_x() * quat.w;
	array[7] = 0;
	array[8] = 2 * quat.get_x() * quat.get_z() - 2 * quat.get_y() * quat.w;
	array[9] = 2 * quat.get_y() * quat.get_z() + 2 * quat.get_x() * quat.w;
	array[10] = 1 - 2 * quat.get_x() * quat.get_x() - 2 * quat.get_y() * quat.get_y();
	array[11] = 0;
	array[12] = 0;
	array[13] = 0;
	array[14] = 0;
	array[15] = 1;
	return (*this);
}

mtx::Matrix4 mtx::Matrix4::perspective(float const &fov, float const &aspect, float const &z_near, float const &z_far) {
	float width = 1.0f / tanf(fov / 2.0f), height = aspect / tanf(fov / 2.0f);

	Matrix4 rtn;
	rtn[0] = width;
	rtn[4] = 0.0f;
	rtn[8] = 0.0f;
	rtn[12] = 0.0f;

	rtn[1] = 0.0f;
	rtn[5] = height;
	rtn[9] = 0.0f;
	rtn[13] = 0.0f;

	rtn[2] = 0.0f;
	rtn[6] = 0.0f;
	rtn[10] = z_far / (z_near - z_far);
	rtn[14] = z_far * z_near / (z_near - z_far);

	rtn[3] = 0.0f;
	rtn[7] = 0.0f;
	rtn[11] = -1.0f;
	rtn[15] = 0.0f;
	return rtn;
}

mtx::Matrix4 mtx::Matrix4::look_at(const mtx::Vec4 &eye, const mtx::Vec4 &at, const mtx::Vec4 &up)
{
	Vec4 x_axis, y_axis, z_axis;
	z_axis = (eye - at).normalize();
	x_axis = up.cross(z_axis).normalize();
	y_axis = z_axis.cross(x_axis).normalize();

	Matrix4 result;
	result[0] = x_axis.get_x();
	result[4] = x_axis.get_y();
	result[8] = x_axis.get_z();
	result[12] = -x_axis.dot(eye);

	result[1] = y_axis.get_x();
	result[5] = y_axis.get_y();
	result[9] = y_axis.get_z();
	result[13] = -y_axis.dot(eye);

	result[2] = z_axis.get_x();
	result[6] = z_axis.get_y();
	result[10] = z_axis.get_z();
	result[14] = -z_axis.dot(eye);

	result[3] = 0.0f;
	result[7] = 0.0f;
	result[11] = 0.0f;
	result[15] = 1.0f;
	return result;
}

/**
 * Operator Overload []
 */
float& mtx::Matrix4::operator[](int const &i) {
	return array[i];
}

/**
 * Operator Overload []
 */
float mtx::Matrix4::operator[](int const &i) const {
	return array[i];
}

/**
 * Assignment Operator
 * Copies values
 */
mtx::Matrix4& mtx::Matrix4::operator=(Matrix4 const &right) {
	for (int i = 0; i < 16; i++) {
		array[i] = right[i];
	}
	return (*this);
}

/**
 * Left Multiplies the Matrix4 by the a scale matrix with x, y, and z equal to right
 * @returns Matrix4 the product
 */
mtx::Matrix4 mtx::Matrix4::operator*(float const &right) const {
	Matrix4 rtn = Matrix4(*this);
	rtn[0] = array[0] * right;
	rtn[1] = array[1] * right;
	rtn[2] = array[2] * right;
	rtn[4] = array[4] * right;
	rtn[5] = array[5] * right;
	rtn[6] = array[6] * right;
	rtn[8] = array[8] * right;
	rtn[9] = array[9] * right;
	rtn[10] = array[10] * right;
	return rtn;
}

/**
 * Matrix4 * Vec4
  * @returns Vec4
 */
mtx::Vec4 mtx::Matrix4::operator*(mtx::Vec4 const &right) const {
	Vec4 result;
	result.get_x() = right.get_x() * array[0] + right.get_y() * array[1] + right.get_z() * array[2] + right.w * array[3];
	result.get_y() = right.get_x() * array[4] + right.get_y() * array[5] + right.get_z() * array[6] + right.w * array[7];
	result.get_z() = right.get_x() * array[8] + right.get_y() * array[9] + right.get_z() * array[10] + right.w * array[11];
	result.w = right.w;
	return result;
}

/**
 * Matrix Multiplication
 * @returns Matrix4 the product
 */
mtx::Matrix4 mtx::Matrix4::operator*(Matrix4 const &right) const {
	Matrix4 result;
	for (int i = 0; i < 4; i++)
	{
		for (int i2 = 0; i2 < 4; i2++)
		{
			float total = 0.0f;
			for (int i3 = 0; i3 < 4; i3++)
			{
				total += array[4 * i + i3] * right[4 * i3 + i2];
			}
			result[4 * i + i2] = total;
		}
	}
	return result;
}

/**
 * Left Multiplies the Matrix4 by the a scale matrix with x, y, and z equal to right
 * @returns Matrix4& (*this)
 */
mtx::Matrix4& mtx::Matrix4::operator*=(float const &right) {
	array[0] *= right;
	array[1] *= right;
	array[2] *= right;
	array[4] *= right;
	array[5] *= right;
	array[6] *= right;
	array[8] *= right;
	array[9] *= right;
	array[10] *= right;
	return (*this);
}

/**
 * Matrix Multiplication
 * @returns Matrix4& (*this)
 */
mtx::Matrix4& mtx::Matrix4::operator*=(const Matrix4 &right) {
	Matrix4 result;
	for (int i = 0; i < 4; i++)
	{
		for (int i2 = 0; i2 < 4; i2++)
		{
			float total = 0.0f;
			for (int i3 = 0; i3 < 4; i3++)
			{
				total += array[4 * i + i3] * right[4 * i3 + i2];
			}
			result[4 * i + i2] = total;
		}
	}
	*this = result;
	return (*this);
}

/**
 * Left Multiplication
 */
mtx::Matrix4& mtx::Matrix4::concatenate(Matrix4 const &right) {
	Matrix4 result;
	for (int i = 0; i < 4; i++)
	{
		for (int i2 = 0; i2 < 4; i2++)
		{
			float total = 0.0f;
			for (int i3 = 0; i3 < 4; i3++)
			{
				total += right[4 * i + i3] * array[4 * i3 + i2];
			}
			result[4 * i + i2] = total;
		}
	}
	*this = result;
	return (*this);
}

mtx::Quaternion::Quaternion() {}

mtx::Quaternion::Quaternion(float const &x, float const &y, float const &z, float const &w) : vector{ x, y, z }, w(w) {}

mtx::Quaternion::Quaternion(Vec3 const &vec, float const &w) : vector(vec), w(w) {}

mtx::Quaternion::Quaternion(Vec3 const &vec) : vector(vec), w(0) {}

mtx::Quaternion::Quaternion(Vec4 const &vec, float const &w) : vector(vec.vector), w(w) {}

mtx::Quaternion::Quaternion(Vec4 const &vec) : vector(vec.vector), w(0) {}

mtx::Quaternion::Quaternion(Quaternion const &copy) : vector{ copy.get_x(), copy.get_y(), copy.get_z() }, w(copy.w) {
}

float& mtx::Quaternion::get_x() {
	return vector.x;
}

float& mtx::Quaternion::get_y() {
	return vector.y;
}

float& mtx::Quaternion::get_z() {
	return vector.z;
}

float mtx::Quaternion::get_x() const {
	return vector.x;
}

float mtx::Quaternion::get_y() const {
	return vector.y;
}

float mtx::Quaternion::get_z() const {
	return vector.z;
}

std::string mtx::Quaternion::to_string() {
	std::string rtn;
	rtn.reserve(50);
	rtn += "s: ";
	std::string str = std::to_string(w);
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + " v: ";
	str = std::to_string(get_x());
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + " ";
	str = std::to_string(get_y());
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + " ";
	str = std::to_string(get_z());
	str.erase(str.find_last_not_of('0') + 1, std::string::npos);
	str.erase(str.find_last_not_of('.') + 1, std::string::npos);
	rtn += str + "\n";
	return rtn;
}

mtx::Quaternion& mtx::Quaternion::operator=(Quaternion const &copy) {
	get_x() = copy.get_x();
	get_y() = copy.get_y();
	get_z() = copy.get_z();
	w = copy.w;
	return (*this);
}

mtx::Quaternion mtx::Quaternion::operator+(Quaternion const &right) {
	return Quaternion(get_x() + right.get_x(), get_y() + right.get_y(), get_z() + right.get_z(), w + right.w);
}

mtx::Quaternion& mtx::Quaternion::operator+=(Quaternion const &right) {
	get_x() += right.get_x();
	get_y() += right.get_y();
	get_z() += right.get_z();
	w += right.w;
	return (*this);
}

mtx::Quaternion mtx::Quaternion::operator-(Quaternion const &right) {
	return Quaternion(get_x() - right.get_x(), get_y() - right.get_y(), get_z() - right.get_z(), w - right.w);
}

mtx::Quaternion& mtx::Quaternion::operator-=(Quaternion const &right) {
	get_x() -= right.get_x();
	get_y() -= right.get_y();
	get_z() -= right.get_z();
	w -= right.w;
	return (*this);
}

mtx::Quaternion mtx::Quaternion::operator*(float const &right) const {
	return Quaternion(vector * right, w * right);
}

mtx::Quaternion mtx::Quaternion::operator*(Quaternion const &right) const {
	return Quaternion(right.vector * w + vector * right.w + vector.cross(right.vector), w * right.w - vector.dot(right.vector));
}

mtx::Quaternion& mtx::Quaternion::operator*=(float const &right) {
	vector *= right;
	w *= right;
	return (*this);
}

mtx::Quaternion& mtx::Quaternion::operator*=(Quaternion const &right) {
	Vec3 vec = right.vector * w + vector * right.w + vector.cross(right.vector);
	w = w * right.w - vector.dot(right.vector);
	vector = vec;
	return (*this);
}

mtx::Quaternion& mtx::Quaternion::concatenate(Quaternion const &right) {
	*this *= right;
	return (*this);
}

float mtx::Quaternion::norm() const {
	return std::sqrt(get_x() * get_x() + get_y() * get_y() + get_z() * get_z() + w * w);
}

mtx::Quaternion& mtx::Quaternion::scale(float const &num) {
	vector *= num;
	w *= num;
	return (*this);
}

mtx::Quaternion& mtx::Quaternion::normalize() {
	float norm = Quaternion::norm();
	vector /= norm;
	w /= norm;
	return (*this);
}

mtx::Quaternion mtx::Quaternion::normal() {

	float norm = Quaternion::norm();
	return Quaternion(vector /= norm, w /= norm);
}


mtx::Quaternion mtx::Quaternion::conjugate() const {
	return Quaternion(vector * -1, w);
}

mtx::Quaternion& mtx::Quaternion::invert() {
	float n = norm();
	vector = vector * -1 / n;
	w /= n;
	return (*this);
}

mtx::Quaternion mtx::Quaternion::inverse() const {
	float n = norm();
	return Quaternion((vector*-1)/n, w/n);
}

mtx::Matrix4 mtx::Quaternion::matrix() const {
	return Matrix4(w, -get_z(), get_y(), get_x(),
		get_z(), w, -get_x(), get_y(),
		-get_y(), get_x(), w, get_z(),
		-get_x(), -get_y(), -get_z(), w);
}

mtx::Quaternion& mtx::Quaternion::make_rotation(Vec3 axis, float angle) {
	Vec3 norm_axis = axis.normal();
	w = std::cosf(angle / 2.0f);
	vector.x = norm_axis.x * std::sinf(angle / 2.0f);
	vector.y = norm_axis.y * std::sinf(angle / 2.0f);
	vector.z = norm_axis.z * std::sinf(angle / 2.0f);
	return (*this);
}