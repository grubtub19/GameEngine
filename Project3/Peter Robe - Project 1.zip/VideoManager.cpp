#include "VideoManager.h"
#include "Logger.h"

VideoManager& VideoManager::get() {
	static VideoManager sSingleton;
	return sSingleton;
}

VideoManager::VideoManager() {
	Logger::log("VideoManager Construction");
}

VideoManager::~VideoManager() {
	Logger::log("VideoManager Destruction");
}

VideoManager& VideoManager::startup() {
	Logger::log("VideoManager starting up");
	return (*this);
}

VideoManager& VideoManager::shutdown() {
	Logger::log("VideoManager shutting down");
	return (*this);
}