#pragma once
#include <string>

namespace mtx {
	
	float to_radians(float const &radians);

	class Vec4;

	class Quaternion;

	class Vec3 {
	public:

		float x, y, z;

		Vec3();
		Vec3(float x, float y, float z);
		Vec3(const Vec3 &vector);
		Vec3(const Vec4 &vector);

		std::string to_string();

		Vec3 operator+(Vec3 const &right) const;
		Vec3 operator+(Vec4 const &right) const;
		Vec3 operator+(float const &right) const;

		Vec3& operator+=(Vec3 const &right);
		Vec3& operator+=(Vec4 const &right);
		Vec3& operator+=(float const &right);

		Vec3 operator-(Vec3 const &right) const;
		Vec3 operator-(Vec4 const &right) const;
		Vec3 operator-(float const &right) const;

		Vec3& operator-=(Vec3 const &right);
		Vec3& operator-=(Vec4 const &right);
		Vec3& operator-=(float const &right);

		Vec3 operator*(float const &right) const;
		Vec3& operator*=(float const &right);

		Vec3 operator/(float const &right) const;
		Vec3& operator/=(float const &right);

		bool operator==(Vec3 const &right) const;
		bool operator==(Vec4 const &right) const;

		bool operator!=(Vec3 const &right) const;
		bool operator!=(Vec4 const &right) const;
		
		float magnitude();

		float magnitude_squared();

		Vec3& normalize();
		Vec3 normal();

		float dot(Vec3 const &right) const;
		float dot(Vec4 const &right) const;

		Vec3 cross(Vec3 const &right) const;
		Vec3 cross(Vec4 const &right) const;

		Vec3 lerp(Vec3 const &right, const float time);
		Vec3 lerp(Vec4 const &right, const float time);

		Vec3 project_onto(Vec3 const &right);
		Vec3 project_onto(Vec4 const &right);

		Vec3 perpendicular(Vec3 const &right);
		Vec3 perpendicular(Vec4 const &right);

		Vec3& rotate(Quaternion &quat);

		float* data_ptr();
	};
	
	class Vec4 {
	public:

				Vec3 vector;
		float w;
		Vec4();
		Vec4(float x, float y, float z, float w);
		Vec4(const Vec3 &vector, float const &w);
		Vec4(const Vec4 &vector);

		float& get_x();
		float& get_y();
		float& get_z();

		float get_x() const;
		float get_y() const;
		float get_z() const;

		std::string to_string();

		Vec4 operator+(Vec3 const &right) const;
		Vec4 operator+(Vec4 const &right) const;
		Vec4 operator+(float const &right) const;

		Vec4& operator+=(Vec3 const &right);
		Vec4& operator+=(Vec4 const &right);
		Vec4& operator+=(float const &right);

		Vec4 operator-(Vec3 const &right) const;
		Vec4 operator-(Vec4 const &right) const;
		Vec4 operator-(float const &right) const;

		Vec4& operator-=(Vec3 const &right);
		Vec4& operator-=(Vec4 const &right);
		Vec4& operator-=(float const &right);

		Vec4 operator*(float const &right) const;
		Vec4& operator*=(float const &right);

		Vec4 operator/(float const &right) const;
		Vec4& operator/=(float const &right);

		bool operator==(Vec3 const &right) const;
		bool operator==(Vec4 const &right) const;

		bool operator!=(Vec3 const &right) const;
		bool operator!=(Vec4 const &right) const;

		float magnitude();

		float magnitude_squared();

		Vec4& normalize();
		Vec4 normal();

		float dot(Vec3 const &right);
		float dot(Vec4 const &right);

		Vec4 cross(Vec3 const &right) const;
		Vec4 cross(Vec4 const &right) const;

		Vec4 lerp(Vec3 const &right, const float time);
		Vec4 lerp(Vec4 const &right, const float time);

		Vec4 project_onto(Vec3 const &right);
		Vec4 project_onto(Vec4 const &right);

		Vec4 perpendicular(Vec3 const &right); //TODO?
		Vec4 perpendicular(Vec4 const &right); //TODO?

		float* data_ptr();
	};
	
	class Matrix4 {
	public:
		float array[16];

		Matrix4();

		Matrix4(bool const &identity);

		Matrix4(float const &num);

		Matrix4(float a1, float a2, float a3, float a4, float b1, float b2, float b3, float b4, float c1, float c2, float c3, float c4, float d1, float d2, float d3, float d4);

		Matrix4(Matrix4 const &original);

		std::string to_string();

		Matrix4& make_identity();

		Matrix4& make_translation(float const &x, float const &y, float const &z);
		Matrix4& make_translation(Vec4 const &direction);

		Matrix4& translate(float const &x, float const &y, float const &z);
		Matrix4& translate(Vec4 const &direction);

		Matrix4& make_scale(float const &x, float const &y, float const &z);
		Matrix4& scale(float const &x, float const &y, float const &z);
		
		Matrix4 inverse();
		Matrix4& invert();

		Matrix4& transpose();

		Matrix4& rotate(Quaternion const &quat);

		Matrix4& make_rotation(Quaternion const &quat);

		Matrix4 perspective(float const &fov, float const &aspect, float const &z_near, float const &z_far);

		Matrix4 look_at(const mtx::Vec4 &Eye, const mtx::Vec4 &At, const mtx::Vec4 &Up);

		float& operator[](int const &i);
		float operator[](int const &i) const;

		Matrix4& operator=(Matrix4 const &right);

		Matrix4 operator*(float const &right) const;
		Vec4 operator*(Vec4 const &right) const ;
		Matrix4 operator*(Matrix4 const &right)const ;

		Matrix4& operator*=(float const &right);
		Matrix4& operator*=(Matrix4 const &right);

		Matrix4& concatenate(Matrix4 const &right);
	};

	class Quaternion {
	public:
		Vec3 vector;
		float w;

		Quaternion();

		Quaternion(float const &x, float const &y, float const &z, float const &w);

		Quaternion(Vec3 const &vec, float const &w);
		Quaternion(Vec3 const &vec);

		Quaternion(Vec4 const &vec, float const &w);
		Quaternion(Vec4 const &vec);

		Quaternion(Quaternion const &copy);
		
		float& get_x();
		float& get_y();
		float& get_z();

		float get_x() const;
		float get_y() const;
		float get_z() const;

		std::string to_string();

		Quaternion& operator=(Quaternion const &right);

		Quaternion operator+(Quaternion const &right);

		Quaternion& operator+=(Quaternion const &right);

		Quaternion operator-(Quaternion const &right);

		Quaternion& operator-=(Quaternion const &right);

		Quaternion operator*(float const &right) const;
		Quaternion operator*(Quaternion const &right) const;

		Quaternion& operator*=(float const &right);
		Quaternion& operator*=(Quaternion const &right);

		Quaternion& concatenate(Quaternion const &right);

		float norm() const;

		Quaternion& scale(float const &num);

		Quaternion& normalize();
		Quaternion normal();

		Quaternion conjugate() const;

		Quaternion inverse() const;
		Quaternion& invert();

		Matrix4 matrix() const;

		Quaternion& make_rotation(Vec3 axis, float angle);
	};
};