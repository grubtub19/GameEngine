#pragma once
#include <string>

static class Logger {
	public:
		static void log(const std::string&);
};