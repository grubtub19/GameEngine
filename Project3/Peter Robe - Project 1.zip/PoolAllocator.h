#pragma once

template <class T> //when using templates, we cannot do implementation in a .cpp file, it must be in the header file
class PoolAllocator {
public:

	union Memory_Block { // this lets us represent the same block of memory as two different types
		T data;					// when get_memory() is called, we stop looking at the Memory_Block as a pointer to another Memory_Block, but instead as an Object of type T
		Memory_Block* next;		// when the Memory_Block is free, it is a pointer to the next free Memory_Block
	};

	Memory_Block* memory; // a pointer to the start of the allocated memory
	Memory_Block* next_free_block; // a pointer to the start of the linked-list of free spaces

	PoolAllocator(unsigned int size) {
		memory = (Memory_Block*) std::malloc(sizeof(Memory_Block) * size); 
		next_free_block = memory; //initially, we consider the first block to be the next free block
		for (int i = 0; i < size - 1; i++) {
			memory[i].next = &memory[i + 1];	// we go through every Memory_Block assigning its value to be a pointer to the next Memory_Block
		}
		memory[size - 1].next = NULL; // if the very last block does not have a next free block
	}

	~PoolAllocator() {
		std::free(memory); //frees all the memory when the PoolAllocator goes out of scope
	}

	T* get_memory() {
		Memory_Block* free_memory = next_free_block;	// we grab the next free Memory_Block to be given away
		if (free_memory == NULL) {				
			Logger::log("Allocator is full");			// if there isn't a free memory block, the allocator is full and we exit the program
			std::cin.ignore();
			exit(EXIT_FAILURE);
		}
		next_free_block = next_free_block->next;		// the next_free_block is now the next in the linked list of free pointers
		return &(free_memory->data);					// we return a pointer to the data representation of the Memory_Block (this is the reason why using a union is important as we cannot return a pointer to a Memory_Block. We have to return a pointer to type T)
	}

	void free(T* pointer) {					// free a used Memory_Block by adding it to the front of the linked list of free Memory_Blocks
		Memory_Block* b_pointer = (Memory_Block*)pointer;
		b_pointer->next = next_free_block;	
		next_free_block = b_pointer;
	}
};