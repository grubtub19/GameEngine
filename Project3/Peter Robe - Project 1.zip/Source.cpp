#include "OpenGLWindow.h"
#include "Mtx.h"
#include "Logger.h"
#include "RenderManager.h"
#include "VideoManager.h"
#include "TextureManager.h"
#include "PoolAllocator.h"
#include <iostream>

RenderManager render = RenderManager::get();
TextureManager texture = TextureManager::get();
VideoManager video = VideoManager::get();
int main(void)
{
	Logger::log("\n------------------------------------------------------------");
	Logger::log("Startup of Components");
	Logger::log("------------------------------------------------------------\n");
	render.startup();
	video.startup();
	texture.startup();
	Logger::log("");
	Logger::log("------------------------------------------------------------");
	Logger::log("Allocate a large number of vertices. Rotate, translate and scale them");
	Logger::log("------------------------------------------------------------\n");
	mtx::Quaternion q;
	q.make_rotation(mtx::Vec3(1.0f, 1.0f, 0.0f), mtx::to_radians(60));
	Logger::log("60 degree rotation around Vec3(1,1,0) is Quaternion:");
	Logger::log(q.to_string());
	mtx::Matrix4 rotation;
	rotation.make_rotation(q);
	Logger::log("Rotation Matrix of Quaternion:");
	Logger::log(rotation.to_string());
	mtx::Matrix4 translation;
	translation.make_translation(mtx::Vec4(20.0f, 30.0f, 40.0f, 0.0f));
	Logger::log("Translation Matrix of Vec4(20,30,40,0):");
	Logger::log(translation.to_string());
	mtx::Matrix4 scale;
	scale.make_scale(2.0f, 3.0f, 4.0f);
	Logger::log("Scale Matrix of Vec3(2,3,4):");
	Logger::log(scale.to_string());

	Logger::log("Allocating 50000 Vec4's\n");
	PoolAllocator<mtx::Vec4> vec4_pool = PoolAllocator<mtx::Vec4>(50000);
	mtx::Vec4* vec4_array[50000];
	for (int i = 0; i < 50000; i++) {
		vec4_array[i] = new (vec4_pool.get_memory()) mtx::Vec4(1.0f, 2.0f, 3.0f, 0.0f);
	}

	for (int i = 0; i < 50000; i+=10000) {
		Logger::log("rotation * translation * scale * vec4_array[" + std::to_string(i) + "]:");
		Logger::log((rotation * translation * scale * (*vec4_array[i])).to_string());
	}

	Logger::log("------------------------------------------------------------");
	Logger::log("Rotate vectors with a set of quaternions then use the inverse to rotate back");
	Logger::log("------------------------------------------------------------\n");
	//std::cin.ignore();
	//OpenGLWindow engine = OpenGLWindow();

	Logger::log("Quaternion q1:");
	mtx::Quaternion q1 = mtx::Quaternion();
	q1.make_rotation(mtx::Vec3(0,1,0), mtx::to_radians(160));
	Logger::log(q1.to_string());

	Logger::log("Quaternion q2:");
	mtx::Quaternion q2 = mtx::Quaternion();
	q2.make_rotation(mtx::Vec3(0, 0, 1), mtx::to_radians(40));
	Logger::log(q2.to_string());

	mtx::Vec3 v = mtx::Vec3(1, 1, 1);
	Logger::log("Vec3 v:");
	Logger::log(v.to_string());

	v.rotate(q1);
	Logger::log("v.rotate(q1):");
	Logger::log(v.to_string());

	v.rotate(q2);
	Logger::log("v.rotate(q2):");
	Logger::log(v.to_string());

	v.rotate(q2.invert());
	Logger::log("v.rotate(q2.inverse()):");
	Logger::log(v.to_string());

	v.rotate(q1.invert());
	Logger::log("v.rotate(q1.inverse()):");
	Logger::log(v.to_string());

	Logger::log("------------------------------------------------------------");
	Logger::log("Shutdown of Components");
	Logger::log("------------------------------------------------------------\n");

	texture.shutdown();
	video.shutdown();
	render.shutdown();

	std::cin.ignore();
}