#include "RenderManager.h"
#include "VideoManager.h"
#include "Logger.h"

RenderManager& RenderManager::get() {
	static RenderManager sSingleton;
	return sSingleton;
}

RenderManager::RenderManager() {
	Logger::log("RenderManager Construction");
}

RenderManager::~RenderManager() {
	Logger::log("RenderManager Destruction");
}

RenderManager& RenderManager::startup() {
	Logger::log("RenderManager starting up");
	return (*this);
}

RenderManager& RenderManager::shutdown() {
	Logger::log("RenderManager shutting down");
	return (*this);
}