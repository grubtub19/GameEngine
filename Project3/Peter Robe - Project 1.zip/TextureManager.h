#pragma once

class TextureManager {
public:
	static TextureManager& get();
	~TextureManager();
	TextureManager& startup();
	TextureManager& shutdown();
private:
	TextureManager();

};
