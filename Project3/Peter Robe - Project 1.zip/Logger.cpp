#include <iostream>
#include <fstream>
#include <string>
#include "Logger.h"

void Logger::log(const std::string& text) {
	//std::ofstream myFile;
	//myFile.open("test.txt");
	//myFile << text << "\n";
	//myFile.close();
	std::cout << text << std::endl;
}