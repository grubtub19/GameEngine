#pragma once

class VideoManager {
public:
	static VideoManager& get();
	~VideoManager();
	VideoManager& startup();
	VideoManager& shutdown();
private:
	VideoManager();

};
