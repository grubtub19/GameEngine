#pragma once

class RenderManager {
public:
	static RenderManager& get();
	~RenderManager();
	RenderManager& startup();
	RenderManager& shutdown();
private:
	RenderManager();
	
};
