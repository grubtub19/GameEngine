#include "TextureManager.h"
#include "Logger.h"

TextureManager& TextureManager::get() {
	static TextureManager sSingleton;
	return sSingleton;
}

TextureManager::TextureManager() {
	Logger::log("TextureManager Construction");
}

TextureManager::~TextureManager() {
	Logger::log("TextureManager Destruction");
}

TextureManager& TextureManager::startup() {
	Logger::log("TextureManager starting up");
	return (*this);
}

TextureManager& TextureManager::shutdown() {
	Logger::log("TextureManager shutting down");
	return (*this);
}